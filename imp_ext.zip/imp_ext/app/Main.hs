module Main where

import Stmt
import Exp
import Common

-- TODO: rezolvat problema cu import-urile (DONE: deschis in locul prost)
-- TODO: de tradus tot in engleza (DONE)
-- TODO: impartirea in fisiere/module (DONE)
-- TODO: unit testing cu HUnit
-- TODO: testare paralelism
-- TODO: compilare si rulare cu ghc pt a specifica nr de procese
-- TODO: poate adaugarea mai multor tipuri de date (char, string, float)

-- newtype Variable = Var String deriving(Eq, Ord, Show)

-- data Value = VInt Int
--              | VBool Bool
--              deriving(Show)

-- newtype MyState = List [(Variable, Value)]

-- newtype MyType = MList (Variable, Value)

main :: IO ()
main = do
    -- Test 1 
    -- let x = Var "x"
    --     stmt1 = Assign x (EInt 1)
    --     stmt2 = Assign x (EInt 2)
    --     program = Seq stmt1 stmt2
    --     MyState = List []
    --     finalState = stmt MyState program
    --     (val, _) = get finalState x
    -- print val

    -- Test 2
    -- let x = Var "x"
    --     y = Var "y"
    --     stmt1 = Assign x (EInt 0)
    --     stmt2 = While (BLt (EVar x) (EInt 3)) (Block [
    --         Assign y (EAdd (EVar x) (EInt 1)),
    --         Assign x (EAdd (EVar x) (EInt 1)) ])
    --     program = Seq stmt1 stmt2
    --     MyState = List []
    --     finalState = stmt MyState program
    --     (val, _) = get finalState y
    -- print val

    -- Test 3
    let x = Var "x"
        y = Var "y"
        p = Par [Assign x (EInt 1), Assign y (EInt 2)]
        s = stmt (List []) p
        (vx, _) = get s x
        (vy, _) = get s y
    print vx
    print vy

